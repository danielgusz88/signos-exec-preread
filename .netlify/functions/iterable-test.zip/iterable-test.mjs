
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/iterable-test.mts
var iterable_test_default = async (req, context) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  const apiKey = Netlify.env.get("ITERABLE_API_KEY");
  if (!apiKey) {
    return new Response(
      JSON.stringify({ success: false, error: "ITERABLE_API_KEY not configured." }),
      { status: 200, headers: corsHeaders }
    );
  }
  try {
    const res = await fetch("https://api.iterable.com/api/channels", {
      headers: { "Api-Key": apiKey }
    });
    if (!res.ok) {
      return new Response(
        JSON.stringify({ success: false, error: `Iterable API returned ${res.status}` }),
        { status: 200, headers: corsHeaders }
      );
    }
    const data = await res.json();
    return new Response(
      JSON.stringify({
        success: true,
        channelCount: data.channels?.length || 0,
        channels: data.channels || []
      }),
      { status: 200, headers: corsHeaders }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: corsHeaders }
    );
  }
};
export {
  iterable_test_default as default
};
